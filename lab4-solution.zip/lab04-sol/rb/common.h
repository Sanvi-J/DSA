#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>
#include <cassert>