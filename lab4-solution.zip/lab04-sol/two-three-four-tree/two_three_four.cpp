// two_three_four.cpp
#include "two_three_four.h"
// -----------------------------
// BigNode constructor
// -----------------------------
BigNode::BigNode()
{
	A = -1;
	B = -1;
	C = -1;
	L = M1 = M2 = R = nullptr;
}

// -----------------------------
// RedBlackTree implementation
// -----------------------------
RedBlackTree::RedBlackTree()
{
	root = nullptr;
}

node *RedBlackTree::getRoot()
{
	return root;
}

void RedBlackTree::setRoot(node *newroot)
{
	root = newroot;
}

// BST-style insert helper
node *RedBlackTree::insert(node *trav, node *temp)
{
	if (trav == nullptr)
		return temp;

	if (temp->d < trav->d)
	{
		trav->l = insert(trav->l, temp);
		if (trav->l)
			trav->l->p = trav;
	}
	else if (temp->d > trav->d)
	{
		trav->r = insert(trav->r, temp);
		if (trav->r)
			trav->r->p = trav;
	}

	return trav;
}

// Helper for pretty printing (internal; not in header)
static void printRBTHelper(node *n, const std::string &prefix, bool isLeft)
{
	if (!n)
		return;
	std::cout << prefix;
	std::cout << (isLeft ? "|--" : "|__");
	std::cout << n->d << "(" << (n->c == 0 ? "B" : "R") << ")" << std::endl;
	printRBTHelper(n->l, prefix + (isLeft ? "│   " : "    "), true);
	printRBTHelper(n->r, prefix + (isLeft ? "│   " : "    "), false);
}

void RedBlackTree::printRBT(const std::string &prefix, bool isLeft)
{
	// public wrapper prints from root; ignore args and use root for consistency
	(void)prefix;
	(void)isLeft;
	printRBTHelper(root, "", true);
}

// right rotation
void RedBlackTree::rightrotate(node *temp)
{
	if (!temp || !temp->l)
		return;
	node *left = temp->l;
	temp->l = left->r;
	if (temp->l)
		temp->l->p = temp;
	left->p = temp->p;
	if (!temp->p)
		root = left;
	else if (temp == temp->p->l)
		temp->p->l = left;
	else
		temp->p->r = left;
	left->r = temp;
	temp->p = left;
}

// left rotation
void RedBlackTree::leftrotate(node *temp)
{
	if (!temp || !temp->r)
		return;
	node *right = temp->r;
	temp->r = right->l;
	if (temp->r)
		temp->r->p = temp;
	right->p = temp->p;
	if (!temp->p)
		root = right;
	else if (temp == temp->p->l)
		temp->p->l = right;
	else
		temp->p->r = right;
	right->l = temp;
	temp->p = right;
}

// standard RB insertion fixup
void RedBlackTree::fixup(node *pt)
{
	while (pt && pt != root && pt->p && pt->p->c == 1)
	{
		node *parent_pt = pt->p;
		node *grand_parent_pt = parent_pt->p;
		if (!grand_parent_pt)
			break;

		if (parent_pt == grand_parent_pt->l)
		{
			node *uncle_pt = grand_parent_pt->r;
			if (uncle_pt && uncle_pt->c == 1)
			{
				// recolor
				grand_parent_pt->c = 1;
				parent_pt->c = 0;
				uncle_pt->c = 0;
				pt = grand_parent_pt;
			}
			else
			{
				if (pt == parent_pt->r)
				{
					leftrotate(parent_pt);
					pt = parent_pt;
					parent_pt = pt->p;
				}
				rightrotate(grand_parent_pt);
				int t = parent_pt->c;
				parent_pt->c = grand_parent_pt->c;
				grand_parent_pt->c = t;
				pt = parent_pt;
			}
		}
		else
		{
			node *uncle_pt = grand_parent_pt->l;
			if (uncle_pt && uncle_pt->c == 1)
			{
				grand_parent_pt->c = 1;
				parent_pt->c = 0;
				uncle_pt->c = 0;
				pt = grand_parent_pt;
			}
			else
			{
				if (pt == parent_pt->l)
				{
					rightrotate(parent_pt);
					pt = parent_pt;
					parent_pt = pt->p;
				}
				leftrotate(grand_parent_pt);
				int t = parent_pt->c;
				parent_pt->c = grand_parent_pt->c;
				grand_parent_pt->c = t;
				pt = parent_pt;
			}
		}
	}
	if (root)
		root->c = 0;
}

void RedBlackTree::inorder(node *trav)
{
	if (!trav)
		return;
	inorder(trav->l);
	std::cout << trav->d << " ";
	inorder(trav->r);
}

// -----------------------------
// TwoThreeFourTree implementation
// -----------------------------
TwoThreeFourTree::TwoThreeFourTree()
{
	tree = new RedBlackTree();
}

void TwoThreeFourTree::insert(int key)
{
	// create new node
	node *temp = new node;
	temp->l = temp->r = temp->p = nullptr;
	temp->d = key;
	temp->c = 1; // new node is red

	// BST insert then fix
	tree->setRoot(tree->insert(tree->getRoot(), temp));
	tree->fixup(temp);
	if (tree->getRoot())
		tree->getRoot()->c = 0;
}

// forward declare helper used only in this cpp
static BigNode *Convert(node *root);

BigNode *TwoThreeFourTree::convert()
{
	return Convert(tree->getRoot());
}

// Convert RB to 2-3-4 BigNode structure
static BigNode *Convert(node *root)
{
	if (!root)
		return nullptr;

	node *L = root->l;
	node *R = root->r;

	BigNode *z = new BigNode();
	z->B = root->d;

	if (root->c == 0)
	{
		if (!L && !R)
		{
			return z;
		}
		else if (!L && R)
		{
			// if R is red leaf, it's C
			if (R->c == 1 && !R->l && !R->r)
			{
				z->C = R->d;
				return z;
			}
			else
			{
				z->R = Convert(R);
				return z;
			}
		}
		else if (L && !R)
		{
			if (L->c == 1 && !L->l && !L->r)
			{
				z->A = L->d;
				return z;
			}
			else
			{
				z->L = Convert(L);
				return z;
			}
		}
		else
		{
			if (L->c == 1)
			{
				z->A = L->d;
				z->L = Convert(L->l);
				z->M1 = Convert(L->r);
			}
			else
			{
				z->L = Convert(L);
			}

			if (R->c == 1)
			{
				z->C = R->d;
				z->M2 = Convert(R->l);
				z->R = Convert(R->r);
			}
			else
			{
				z->R = Convert(R);
			}
			return z;
		}
	}
	else
	{
		// red node -- shouldn't be top-level, but convert children
		z->L = Convert(L);
		z->R = Convert(R);
		return z;
	}
}

// print 2-3-4 tree in-order
void TTF(BigNode *root)
{
	if (!root)
		return;
	if (root->L)
		TTF(root->L);
	if (root->A != -1)
		std::cout << root->A << " ";
	if (root->M1)
		TTF(root->M1);
	if (root->B != -1)
		std::cout << root->B << " ";
	if (root->M2)
		TTF(root->M2);
	if (root->C != -1)
		std::cout << root->C << " ";
	if (root->R)
		TTF(root->R);
}
