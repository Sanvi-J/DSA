# LCA

# Problem Description

Recall the definition of least common ancestor (LCA) from class and tutorial. 
Given a binary tree T and two nodes a and b, the LCA of a and b is the node v 
such that v is an ancestor of both a and b, and v is the lowest node with this property. 
For example, in the tree below, the LCA of nodes 4 and 5 is node 2, and the LCA of nodes 4 and 6 is node 1.
Tree:
    1
   / \
  2   3
 / \ / \
4  5 6  7

# YOUR TASK

0. We already discussed the algorithm to find LCA in tutorial.
1. Complete the function findlca(a, b) in lca.cpp that takes pointer to two nodes a and b, and returns the pointer to LCA node of a and b.
2. The given tree is not necessarily a binary search tree. You may assume that both a and b are in the same tree if they are not NULL.
3. You have been provided with 10 sample testcases. These testcases by no means cover all possible testcases. 
   You are encouraged to write your own testcases to test your code.
4. Check for all possible corner cases.
5. Note that there is no constraint on the number of nodes in the tree. 
6. To test your code, run the following commands:
    For auto-testing on given testcases:
    - make runtests
    For interactive testing:(look at what all interactive commands are allowed in main.cpp)
    - make interactive


# Files to Edit (DO NOT MODIFY ANYTHING ELSE)

DO NOT CHANGE ANYTHING IN FILES EXCEPT findlca.cpp AS WE WILL ONLY TAKE YOUR findlca.cpp FILE FOR EVALUATION.

# Input and Output

Note that in tests folder, each testcase input tree and 2 labels is present in input.txt. Last line of input.txt contains label of nodes a and b separated by space. 

Tree format and handling of tree is given tree_handling.txt

The expected output from each testcase is given in tests/test<i>/output.txt file. 


# Interactive mode

For interactive testing, you can create your own tree using interactive commands.
To create the tree, create file e.g. tree.txt and use the following commands:

LOAD tree.txt
PRINT
FINDLCA 2 3

Look at tree_handling.txt to understand the tree format.

