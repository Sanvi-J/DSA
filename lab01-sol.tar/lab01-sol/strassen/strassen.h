// ************************************************************
// DO NOT CHANGE ANYTHING IN THIS FILE
// ************************************************************

Matrix strassenMultiply(const Matrix &A, const Matrix &B, int threshold);
Matrix naiveMultiply(const Matrix &A, const Matrix &B);
bool equal(const Matrix &A, const Matrix &B);
