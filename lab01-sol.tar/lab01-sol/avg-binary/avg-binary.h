// ************************************************************
// DO NOT CHANGE ANYTHING IN THIS FILE
// ************************************************************

double drive_binary_search(unsigned size);
